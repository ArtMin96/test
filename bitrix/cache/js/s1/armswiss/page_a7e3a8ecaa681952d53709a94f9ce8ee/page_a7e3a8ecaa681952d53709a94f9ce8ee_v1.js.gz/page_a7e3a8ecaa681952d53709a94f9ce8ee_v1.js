
; /* Start:"a:4:{s:4:"full";s:83:"/bitrix/components/bitrix/main.share/templates/.default/script.min.js?1575881824468";s:6:"source";s:65:"/bitrix/components/bitrix/main.share/templates/.default/script.js";s:3:"min";s:69:"/bitrix/components/bitrix/main.share/templates/.default/script.min.js";s:3:"map";s:69:"/bitrix/components/bitrix/main.share/templates/.default/script.map.js";}"*/
function ShowShareDialog(e){var n=document.getElementById("share-dialog"+e);if(!n)return;if(n.style.display=="block"){n.style.display="none"}else{n.style.display="block"}return false}function CloseShareDialog(e){var n=document.getElementById("share-dialog"+e);if(!n)return;n.style.display="none";return false}function __function_exists(e){if(typeof e=="string"){return typeof window[e]=="function"}else{return e instanceof Function}}
/* End */
;; /* /bitrix/components/bitrix/main.share/templates/.default/script.min.js?1575881824468*/

//# sourceMappingURL=page_a7e3a8ecaa681952d53709a94f9ce8ee.map.js